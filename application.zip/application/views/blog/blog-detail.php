<div class="container py-4">

						<div class="col">
							<div class="blog-posts single-post">
							
								<article class="post post-large blog-single-post border-0 m-0 p-0">
<div class="post-image ml-0">
										<a href="blog-post.html">
											<img src="<?php echo base_url()?>/assets/img/blog/<?php echo $blogs['cover']; ?>" class="img img-fluid img-thumbnail img-thumbnail-no-borders rounded" alt="" />
										</a>
									</div>
							
									<div class="post-content ml-0">
							
										<h2 class="font-weight-bold"><a href="blog-post.html"><?php echo $blogs['title']; ?></a></h2>
							
										<div class="post-meta">
											<span><i class="far fa-user"></i> By <a href="#"><?php echo $blogs['penulis'] ?></a> </span>
											<span><i class="far fa-folder"></i> <a href="#">Tanggal Posting </a>, <a href="#"><?php echo $blogs['date'] ?></a> </span>
											<span><i class="far fa-comments"></i> <a href="#">12 Comments</a></span>
										</div>

										<p align="justify">
                                            <?php echo $blogs['content'] ?>
                                        </p>
							
							
										
							
									</div>
								</article>
							
							</div>
						</div>
					</div>

				</div>

		